package com.lec.loop;
// for - 정해진 횟수만큼 반복
public class Ex01for {
	public static void main(String[] args) {
		
		for(int i=0 ; i<5 ; i++) {
			System.out.println("안녕하세요");
		}
		// System.out.println(i);
	}
}
