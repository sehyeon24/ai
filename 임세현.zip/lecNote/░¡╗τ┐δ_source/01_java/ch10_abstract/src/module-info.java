/**
 * 
 */
/**
 * 
 */
module ch10_abstract {
}