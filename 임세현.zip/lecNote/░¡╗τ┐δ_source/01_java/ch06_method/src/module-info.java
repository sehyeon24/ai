/**
 * 
 */
/**
 * 
 */
module ch06_method {
}