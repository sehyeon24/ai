package com.lec.ex1;
// 추상메소드, static final 변수(상수)만 가능 - public
public interface InterfaceEx1 {
	public /* static final*/ int CONSTANT_NUM = 10;
	public /*abstract*/ void method1();
}
