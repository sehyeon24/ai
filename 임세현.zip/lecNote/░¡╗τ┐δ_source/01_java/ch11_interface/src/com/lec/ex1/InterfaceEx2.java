package com.lec.ex1;
public interface InterfaceEx2 {
	public String CONSTANT_STRING = "Hello, world";
	public void method2();
}
