package com.lec.ex4_actor;
public interface IChef {
	public void makePizza();
	public void makeSpaghetti();
}
