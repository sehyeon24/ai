package com.lec.ex4_actor;
public interface IFireFighter {
	public void outFire();
	public void saveMan();
}
