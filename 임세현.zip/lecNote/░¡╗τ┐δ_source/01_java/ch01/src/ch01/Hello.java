package ch01;
// 한줄 주석
public class Hello {
	public static void main(String[] args) {
		/* System은 Java에서 제공하는 꾸러미(API=라이브러리)
		 * dot(.) : System이라는 꾸러미 안의 out
		 */
		System.out.println("Hello, Java");
		System.out.println('H');
	}
}
