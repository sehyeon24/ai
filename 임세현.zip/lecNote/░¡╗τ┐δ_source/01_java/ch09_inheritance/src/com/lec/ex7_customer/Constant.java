package com.lec.ex7_customer;
public class Constant {
	public static final int VIPLIMIT = 1000000;
	public static final double POINTRATE = 0.01;
}
