package com.lec.ex3_abc;
// s
public class A extends S {
	public A() {
		System.out.println("A형 객체 생성 s=1");
		s = 1;
	}
}
