package com.lec.ex1_parentChild;
//pStr, getPapaName(), getMamiName()
public class ChildClass extends ParentClass{
	String cStr = "자식클래스";
	public ChildClass() {
		System.out.println("자식 클래스 생성자");
	}
}
