package com.lec.ex3_abc;
public class B extends S{
	public B() {
		System.out.println("B형 객체 생성 s=2");
		s = 2;
	}
}
