package com.lec.ex3_abc;
public class S {
	protected int s;
	public S() {
		System.out.println("-------------------------");
		System.out.println("매개변수가 없는 부모클래스 생성자");
	}	
}
