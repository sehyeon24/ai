/**
 * 
 */
/**
 * 
 */
module ch09_inheritance {
}