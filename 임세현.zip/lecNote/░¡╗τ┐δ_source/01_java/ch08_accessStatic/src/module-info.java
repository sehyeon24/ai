/**
 * 
 */
/**
 * 
 */
module ch08_accessStatic {
}