package com.lec.ex3_static;

public class Mom {
	int money = 2000; // 데이터 초기화 방법2
//	public Mom() { // 데이터 초기화 방법1 : 생성자 이용
//		money = 2000;
//	}
}
