package constant;

public class Constant {
	public static final double PI = 3.141592;
}
