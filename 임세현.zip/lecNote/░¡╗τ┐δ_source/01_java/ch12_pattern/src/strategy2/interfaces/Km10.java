package strategy2.interfaces;

public class Km10 implements KmImpl {
	@Override
	public void kmPerLiter() {
		System.out.println("연비가 10km/l입니다");
	}
}
