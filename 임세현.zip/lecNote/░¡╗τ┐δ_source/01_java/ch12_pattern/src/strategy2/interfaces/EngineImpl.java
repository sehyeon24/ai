package strategy2.interfaces;
public interface EngineImpl {
	public void engine();
}
