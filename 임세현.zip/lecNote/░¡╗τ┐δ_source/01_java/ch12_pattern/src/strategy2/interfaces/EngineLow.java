package strategy2.interfaces;
public class EngineLow implements EngineImpl {
	@Override
	public void engine() {
		System.out.println("저급 엔진입니다");
	}
}