package strategy2.interfaces;

public class EngineHigh implements EngineImpl {
	@Override
	public void engine() {
		System.out.println("최고급 엔진입니다");
	}
}
