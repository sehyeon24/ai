package strategy2.interfaces;

public class Km20 implements KmImpl {
	@Override
	public void kmPerLiter() {
		System.out.println("연비가 20km/l입니다");
	}
}
