package strategy2.interfaces;
public interface KmImpl {
	public void kmPerLiter();
}
