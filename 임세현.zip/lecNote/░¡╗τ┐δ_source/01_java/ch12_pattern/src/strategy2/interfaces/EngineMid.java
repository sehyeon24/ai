package strategy2.interfaces;
public class EngineMid implements EngineImpl {
	@Override
	public void engine() {
		System.out.println("중급 엔진입니다");
	}
}