package strategy2.interfaces;

public interface FuelImpl {
	public void fuel();
}
