package strategy2.interfaces;

public class Km15 implements KmImpl {
	@Override
	public void kmPerLiter() {
		System.out.println("연비가 15km/l입니다");
	}
}
