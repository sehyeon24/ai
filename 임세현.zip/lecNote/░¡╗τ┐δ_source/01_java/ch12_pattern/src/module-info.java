/**
 * 
 */
/**
 * 
 */
module ch12_pattern {
}