package strategy1.step4.interfaces;
public class FlyYes implements FlyImpl {
	@Override
	public void fly() {
		System.out.println("날 수 있습니다");
	}
}
