package strategy1.step4.interfaces;
public interface MissileImpl {
	public void missile();
}
