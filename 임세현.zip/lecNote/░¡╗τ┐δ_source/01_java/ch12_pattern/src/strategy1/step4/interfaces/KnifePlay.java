package strategy1.step4.interfaces;

public class KnifePlay implements KnifeImpl {

	@Override
	public void knife() {
		System.out.println("장난감 검이 있습니다");
	}

}
