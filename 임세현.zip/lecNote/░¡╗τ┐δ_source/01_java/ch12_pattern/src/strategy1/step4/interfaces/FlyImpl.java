package strategy1.step4.interfaces;
public interface FlyImpl {
	public void fly();
}
