package strategy1.step4.interfaces;
public class KnifeNo implements KnifeImpl {
	@Override
	public void knife() {
		System.out.println("검이 없습니다");
	}
}