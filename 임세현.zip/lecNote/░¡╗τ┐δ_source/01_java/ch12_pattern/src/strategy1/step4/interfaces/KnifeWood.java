package strategy1.step4.interfaces;
public class KnifeWood implements KnifeImpl {
	@Override
	public void knife() {
		System.out.println("목검이 있습니다.");
	}
}