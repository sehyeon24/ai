package strategy1.step4.interfaces;
public interface KnifeImpl {
	public void knife();
}