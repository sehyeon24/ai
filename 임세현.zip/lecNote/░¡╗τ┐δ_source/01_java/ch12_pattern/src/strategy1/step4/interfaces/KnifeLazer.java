package strategy1.step4.interfaces;
public class KnifeLazer implements KnifeImpl {
	@Override
	public void knife() {
		System.out.println("레이저 검이 있습니다.");
	}
}