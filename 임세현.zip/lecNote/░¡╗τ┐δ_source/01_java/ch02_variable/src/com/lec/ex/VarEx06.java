package com.lec.ex;

public class VarEx06 {
	public static void main(String[] args) {
		// 기초데이터 타입
		int i;
		i = 10;
		char gender = '남';
		// 참조데이터 타입(객체 데이터 타입)
		String name = "Hong";
		name = "김수한무거북이와두루미";
		i = 100;
	}
}
