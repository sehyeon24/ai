package com.lec.ex3_abc;

public class C extends S {
	public C() {
		System.out.println("C형 객체 생성 s=3");
		s = 3;
	}
}
