package com.lec.ex3_abc;
// S의 protected int s;가 추가됨
public class A extends S {
	public A() {
		System.out.println("A형 객체 생성 s=1");
		s = 1;
	}
}
