package com.lec.ex7_customer;
// Customer 클래스 내 상수 만들기
public class Constant {
	public static final int VIPLIMMIT = 1000000;	// 안 바뀌는 final변수는 대문자
	public static final double POINTRATE = 0.01;
	
	
}
