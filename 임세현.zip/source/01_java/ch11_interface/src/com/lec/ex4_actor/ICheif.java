package com.lec.ex4_actor;

public interface ICheif {
	public void makePizza();
	public void makeSpaghetti();
}
