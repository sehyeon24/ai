package com.lec.ex1;

public interface InterfaceEx2 {
	public String CONSTANT_STRING = "Hello, world";
	public void method2();	// method선언만 해도 추상메소드임
	
}
