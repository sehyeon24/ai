package com.lec.loop;
//
public class Ex11doWhle {
	public static void main(String[] args) {
		do {
			System.out.println("안녕");
		}while (true);
		
		// System.out.println("무한 반복문 뒤에는 에러");
	}
}
