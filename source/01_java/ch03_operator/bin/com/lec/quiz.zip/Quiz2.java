package com.lec.quiz;
// 국어, 영어, 수학 점수를 사용자에게 입력받아, 각 점수를 출력하고 총점, 평균(소수점2자리까지) 출력하는 프로그램을 구현 하시오
public class Quiz2 {
	public static void main(String[] args) {
		int kor = 100, eng = 100, mat = 90;
		int tot = kor + eng + mat;
//		int avg = tot ㅠㅠ
		System.out.println("국어 : " + kor + "\t 영어 : " + eng + "\t 수학 : " + mat);
		System.out.println("총점 : " + tot);
//		System.out.println("평균 : " + avg);
	}
}
