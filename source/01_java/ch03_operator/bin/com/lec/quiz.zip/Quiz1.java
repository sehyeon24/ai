package com.lec.quiz;
// 입력한 수가 짝수인지 홀수인지 출력
public class Quiz1 {
	public static void main(String[] args) {
		int n1=1;
		int result;
		if (n1%2==0) {
			System.out.println("n1은 짝수입니다");
		}else {
			System.out.println("n1은 홀수입니다");
			
//		Scanner sc = new Scanner(System.in);
//		System.out.print("정수를 입력하세요 >");
//		String result = (su%)
		}
	}
}

